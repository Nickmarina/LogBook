
import UU5 from "uu5g04";

export const AircraftsContext = UU5.Common.Context.create();
export default AircraftsContext;