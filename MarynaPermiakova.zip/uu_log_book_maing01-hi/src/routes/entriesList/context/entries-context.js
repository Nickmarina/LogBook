import UU5 from "uu5g04";

export const EntriesContext = UU5.Common.Context.create();
export default EntriesContext;
