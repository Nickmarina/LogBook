import UU5 from "uu5g04";

export const AircraftContext = UU5.Common.Context.create();
export default AircraftContext;
